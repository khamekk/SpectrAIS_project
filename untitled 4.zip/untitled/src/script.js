document.addEventListener("DOMContentLoaded", function() {

    // =======================
    // STARS BACKGROUND
    // =======================
    const canvas = document.getElementById("stars");
    const ctx = canvas.getContext("2d");

    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    let stars = [];
    function initStars() {
        stars = [];
        for (let i = 0; i < 400; i++) {
            stars.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                size: Math.random() * 2.5,
                speed: Math.random() * 0.3 + 0.1
            });
        }
    }
    initStars();
    window.addEventListener('resize', initStars);

    function animateStars() {
        ctx.fillStyle = "black";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "#7df9ff";

        stars.forEach(s => {
            s.y -= s.speed;
            if (s.y < 0) s.y = canvas.height;
            ctx.beginPath();
            ctx.arc(s.x, s.y, s.size, 0, Math.PI * 2);
            ctx.fill();
        });

        requestAnimationFrame(animateStars);
    }
    animateStars();

    // =======================
    // PAGES
    // =======================
    const page1 = document.getElementById("page1");
    const page2 = document.getElementById("page2");
    const aiMessage = document.getElementById("aiMessage");

    document.getElementById("backBtn").onclick = () => {
        page2.style.display = "none";
        page1.style.display = "block";
        aiMessage.innerHTML = 'Waiting for analysis...';
    };

    // =======================
    // COUNTRIES DATABASE
    // =======================
    const countriesByContinent = {
        asia: ["China", "India", "Japan", "South Korea", "Indonesia", "Thailand", "Vietnam", "Malaysia", "Singapore", "Philippines", "Kazakhstan"],
        europe: ["United Kingdom", "France", "Germany", "Italy", "Spain", "Netherlands", "Sweden", "Finland", "Norway", "Denmark", "Russia", "Ukraine", "Belarus", "Austria", "Hungary"],
        africa: ["Egypt", "South Africa", "Nigeria", "Kenya", "Morocco", "Ghana", "Ethiopia", "Tanzania", "Algeria"],
        northamerica: ["United States", "Canada", "Mexico", "Greenland", "Cuba", "Jamaica", "Haiti"],
        southamerica: ["Brazil", "Argentina", "Chile", "Peru", "Colombia", "Venezuela", "Ecuador", "Bolivia"],
        australia: ["Australia", "New Zealand", "Papua New Guinea", "Fiji"],
        antarctica: ["Antarctica (Research Stations)"]
    };

    const continentSelect = document.getElementById("continent");
    const countrySelect = document.getElementById("country");

    continentSelect.addEventListener("change", function() {
        const selected = this.value;
        countrySelect.innerHTML = "<option value=''>🗺️ Select Country</option>";

        if (!countriesByContinent[selected]) return;

        countriesByContinent[selected].forEach(country => {
            const opt = document.createElement("option");
            opt.value = country;
            opt.textContent = country;
            countrySelect.appendChild(opt);
        });
    });

    // =======================
    // TIME OF DAY
    // =======================
    function getTimeOfDay() {
        const h = new Date().getHours();
        if (h >= 5 && h < 12) return "Morning";
        if (h >= 12 && h < 17) return "Afternoon";
        if (h >= 17 && h < 21) return "Evening";
        return "Night";
    }

    // =======================
    // NOAA DATA
    // =======================
    let noaaData = [];

    function createSampleData() {
        return [
            { country: "China", flux: 185, solarWind: 520, magneticField: 35 },
            { country: "India", flux: 95, solarWind: 430, magneticField: 28 },
            { country: "Japan", flux: 220, solarWind: 580, magneticField: 42 },
            { country: "United States", flux: 90, solarWind: 440, magneticField: 26 },
            { country: "United Kingdom", flux: 40, solarWind: 370, magneticField: 16 },
            { country: "Germany", flux: 45, solarWind: 380, magneticField: 18 },
            { country: "France", flux: 55, solarWind: 400, magneticField: 20 },
            { country: "Brazil", flux: 115, solarWind: 470, magneticField: 31 },
            { country: "Australia", flux: 105, solarWind: 455, magneticField: 29 },
            { country: "Russia", flux: 30, solarWind: 350, magneticField: 12 },
            { country: "Canada", flux: 35, solarWind: 360, magneticField: 14 },
            { country: "Mexico", flux: 75, solarWind: 420, magneticField: 24 },
            { country: "South Africa", flux: 130, solarWind: 490, magneticField: 33 },
            { country: "Egypt", flux: 180, solarWind: 560, magneticField: 40 },
            { country: "Argentina", flux: 125, solarWind: 485, magneticField: 32 },
            { country: "Kazakhstan", flux: 85, solarWind: 450, magneticField: 25 },
            { country: "Indonesia", flux: 175, solarWind: 550, magneticField: 38 },
            { country: "Greenland", flux: 25, solarWind: 340, magneticField: 10 },
            { country: "Antarctica (Research Stations)", flux: 250, solarWind: 620, magneticField: 48 }
        ];
    }

    // Load or create data
    fetch("noaa_data.json")
        .then(r => r.json())
        .then(data => {
            noaaData = data;
            console.log("✅ NOAA data loaded successfully");
        })
        .catch(() => {
            console.log("📡 Using sample NOAA data");
            noaaData = createSampleData();
        });

    // =======================
    // SOLAR ANALYSIS FUNCTIONS
    // =======================
    function getSolarData(country) {
        return noaaData.find(e => e.country === country) || { 
            flux: Math.floor(Math.random() * 250) + 20,
            solarWind: Math.floor(Math.random() * 300) + 300
        };
    }

    function getFlareClass(flux) {
        if (flux < 50) return "A";
        if (flux < 100) return "B";
        if (flux < 200) return "C";
        if (flux < 300) return "M";
        return "X";
    }

    function getFlareDescription(flux) {
        if (flux < 50) return "Very Low";
        if (flux < 100) return "Low";
        if (flux < 200) return "Moderate";
        if (flux < 300) return "High";
        return "Extreme";
    }

    function getRiskLevel(flux) {
        if (flux < 50) return "🟢 Minimal";
        if (flux < 100) return "🟡 Low";
        if (flux < 200) return "🟠 Moderate";
        if (flux < 300) return "🔴 High";
        return "⚫ CRITICAL";
    }

    // =======================
    // AI ADVICE GENERATION
    // =======================
    async function generateAIAdvice(country, solarData, flareClass, probability, timeOfDay) {
        const aiElement = document.querySelector('.ai');
        aiElement.innerHTML = '🤖 AI Advisor: <span class="loading">Analyzing solar activity and calculating risks...</span>';
        
        try {
            // Simulate AI processing (remove this in production with real API)
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            const flux = solarData.flux;
            const riskLevel = getRiskLevel(flux);
            const flareDesc = getFlareDescription(flux);
            
            // Generate intelligent advice based on data
            let advice = "";
            
            if (flareClass === "A" || flareClass === "B") {
                advice = `✅ MINOR ACTIVITY: Class ${flareClass} solar flare detected with ${probability}% probability. No immediate action required. Standard operations can continue normally. The solar wind speed is ${solarData.solarWind} km/s, which is within normal parameters.`;
            } 
            else if (flareClass === "C") {
                advice = `⚠️ MODERATE ACTIVITY: Class ${flareClass} solar flare (${flareDesc}) with ${probability}% probability. 
                
• AVIATION: Expect minor HF radio disruptions on polar routes. Airlines should consider alternative routes.
• POWER GRID: Minor voltage fluctuations possible. Grid operators should monitor systems.
• PUBLIC: No direct health risks. Sensitive electronics may experience minor interference.
• RECOMMENDATION: Keep emergency communication systems on standby.`;
            }
            else if (flareClass === "M") {
                advice = `🔴 HIGH ACTIVITY: Class ${flareClass} solar flare detected! Probability: ${probability}%. Risk level: ${riskLevel}
                
• AVIATION: Significant radio blackouts possible. Flights above 25,000 feet near poles should be rerouted.
• POWER GRID: Voltage corrections likely. Prepare for possible transformer issues.
• PUBLIC: Astronauts and high-altitude flights face increased radiation. General public safe.
• SATELLITES: Orbital corrections may be needed. GPS accuracy could degrade.
• RECOMMENDATION: Delay sensitive space operations. Inform aviation authorities.`;
            }
            else {
                advice = `🚨 EXTREME SOLAR EVENT: Class ${flareClass} flare! Probability: ${probability}%. SEVERE CONDITIONS PREDICTED!

• AVIATION: IMMEDIATE ACTION - Ground flights in polar regions. Complete HF communication loss likely.
• POWER GRID: Widespread voltage problems. Emergency protocols should be activated.
• PUBLIC: Avoid unnecessary travel. Have backup power and communication ready.
• ELECTRONICS: Widespread GPS and satellite navigation disruptions expected.
• CRITICAL RECOMMENDATIONS: 
  - Activate emergency response teams
  - Prepare for possible blackouts
  - Monitor official space weather alerts
  - Postpone all non-essential electronic operations`;
            }
            
            // Add location and time specific advice
            advice += `\n\n📍 Location: ${country} (${timeOfDay} time). Stay tuned for updates every 6 hours.`;
            
            aiElement.innerHTML = `🤖 AI SPACE WEATHER ADVISOR:<br><br>${advice}`;
            
        } catch (error) {
            console.error('AI generation error:', error);
            aiElement.innerHTML = `🤖 AI Advisor: Unable to connect to analysis servers. Using backup protocols. ${getBackupAdvice(flareClass, probability)}`;
        }
    }

    function getBackupAdvice(flareClass, probability) {
        const advice = {
            A: "No significant solar activity detected. Continue normal operations.",
            B: "Minor solar activity. Monitor communication systems.",
            C: "Moderate solar activity possible. Standard precautions recommended.",
            M: "High solar activity detected. Activate emergency communication protocols.",
            X: "CRITICAL: Extreme solar weather. Follow emergency procedures immediately."
        };
        return advice[flareClass] || "Monitor official space weather alerts.";
    }

    // =======================
    // START MISSION
    // =======================
    document.getElementById("startBtn").onclick = async () => {
        const country = countrySelect.value;
        if (!country) {
            alert("⚠️ Please select a country for analysis");
            return;
        }

        // Switch to results page
        page1.style.display = "none";
        page2.style.display = "block";

        // Get solar data
        const solarData = getSolarData(country);
        const flareClass = getFlareClass(solarData.flux);
        const probability = Math.min(99, Math.round(solarData.flux / 2.5));
        const timeOfDay = getTimeOfDay();

        // Update UI with data
        document.getElementById("time").innerHTML = `📍 ${country} | ${timeOfDay} UTC`;
        document.getElementById("class").innerHTML = `${flareClass} (${getFlareDescription(solarData.flux)})`;
        document.getElementById("prob").innerHTML = `${probability}%`;
        document.getElementById("aviation").innerHTML = getRiskLevel(solarData.flux);
        document.getElementById("power").innerHTML = getRiskLevel(solarData.flux * 0.8);
        document.getElementById("humans").innerHTML = getRiskLevel(solarData.flux * 0.5);
        document.getElementById("devices").innerHTML = getRiskLevel(solarData.flux * 0.9);

        // Generate AI advice
        await generateAIAdvice(country, solarData, flareClass, probability, timeOfDay);
    };

    // Add some cool effects
    const style = document.createElement('style');
    style.textContent = `
        .value-highlight {
            color: #00ffaa !important;
            text-shadow: 0 0 10px #00ffaa;
        }
        .loading {
            animation: pulse 1.5s infinite;
        }
    `;
    document.head.appendChild(style);
});